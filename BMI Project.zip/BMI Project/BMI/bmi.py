# BMI Calculator with result classification

# Ask the user to enter their weight in kg
weight = float(input("Enter your weight in kg: "))

# Ask the user to enter their height in cm
height = float(input("Enter your height in cm: "))

# Convert height from cm to m
height = height / 100

# Calculate BMI
bmi = weight / (height ** 2)

# Classify the result
if bmi < 18.5:
    result = "Underweight"
elif 18.5 <= bmi < 25:
    result = "Normal weight"
elif 25 <= bmi < 30:
    result = "Overweight"
else:
    result = "Obesity"

# Display the result
print("Your BMI is:", bmi)
print("Result:", result)
